i = 0 
sum = 0
a = (i * i * i)
while i<100 :

    sum = sum + a 
    i = i + 1
    a = (i * i * i) 
breakpoint()
print(sum)
